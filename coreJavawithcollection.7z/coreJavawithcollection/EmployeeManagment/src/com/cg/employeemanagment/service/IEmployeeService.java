package com.cg.employeemanagment.service;

import java.util.List;

import com.cg.employeemanagment.dto.Employee;

public interface IEmployeeService {

	public void addEmployee(Employee emp);
	public List<Employee> showAll();
	public Employee searchEmployee(int empId);
	public void removeEmployee(int empId);
}
