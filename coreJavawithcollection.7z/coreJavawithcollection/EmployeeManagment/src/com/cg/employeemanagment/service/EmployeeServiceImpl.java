package com.cg.employeemanagment.service;

import java.util.List;

import com.cg.employeemanagment.dao.EmployeeDaoImpl;
import com.cg.employeemanagment.dao.IEmployeeDao;
import com.cg.employeemanagment.dto.Employee;

public class EmployeeServiceImpl implements IEmployeeService  {
IEmployeeDao employeeDao=new EmployeeDaoImpl();
	@Override
	public void addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		employeeDao.addDataEmployee(emp);
	}

	@Override
	public List<Employee> showAll() {
		// TODO Auto-generated method stub
		return employeeDao.showAllData();
	}

	@Override
	public Employee searchEmployee(int empId) {
		// TODO Auto-generated method stub
		return employeeDao.searchData(empId);
	}

	@Override
	public void removeEmployee(int empId) {
		// TODO Auto-generated method stub
		employeeDao.reamoveData(empId);
	}

	

}
