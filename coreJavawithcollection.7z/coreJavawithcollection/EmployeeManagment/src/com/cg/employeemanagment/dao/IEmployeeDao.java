package com.cg.employeemanagment.dao;

import java.util.List;

import com.cg.employeemanagment.dto.Employee;

public interface IEmployeeDao {
	
	public void addDataEmployee(Employee emp);
	public List<Employee> showAllData();
	public Employee searchData(int empId);
	public void reamoveData(int empId);

}
