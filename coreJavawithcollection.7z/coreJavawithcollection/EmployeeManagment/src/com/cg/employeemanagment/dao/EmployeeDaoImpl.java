package com.cg.employeemanagment.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.employeemanagment.dto.Employee;

public class EmployeeDaoImpl implements IEmployeeDao {

	List<Employee> myList=new ArrayList<Employee>();
	@Override
	public void addDataEmployee(Employee emp) {
		// TODO Auto-generated method stub
		myList.add(emp);
		
	}

	@Override
	public List<Employee> showAllData() {
		// TODO Auto-generated method stub
		return myList;
	}

	@Override
	public Employee searchData(int empId) {
		// TODO Auto-generated method stub
		Employee empSear=null;
		for (Employee empsearch : myList) {
			if(empsearch.getEmpId()==empId){
				empSear=empsearch;
				break;
			}
			
		}
		return empSear;
	}

	@Override
	public void reamoveData(int empId) {
		// TODO Auto-generated method stub
		//Employee empSear=null;
		for (Employee empsearch : myList) {
			if(empsearch.getEmpId()==empId){
				myList.remove(empsearch);
				break;
			}
			
		}
	}

}
