package com.cg.employeemanagment.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.employeemanagment.dto.Employee;
import com.cg.employeemanagment.service.EmployeeServiceImpl;
import com.cg.employeemanagment.service.IEmployeeService;

public class EmployeeApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IEmployeeService empService=new EmployeeServiceImpl();
		int choice=0;
		do{
			printDetail();
		Scanner scr=new Scanner(System.in);
		choice=scr.nextInt();
		switch(choice){
		case 1://ADD
			System.out.println(" Enter Employee Id");
			int empId=scr.nextInt();
			System.out.println(" Enter Employee Name");
			String empName=scr.next();
			System.out.println(" Enter Employee Department");
			String empDep=scr.next();
			System.out.println(" Enter Employee Salary");
			double empSalary=scr.nextDouble();
			
			Employee emp=new Employee();
			emp.setEmpId(empId);
			emp.setEmpName(empName);
			emp.setEmpDepartment(empDep);
			emp.setEmpSalary(empSalary);
			
			empService.addEmployee(emp);
			break;
		case 2://Show All
			List<Employee> myEmp=empService.showAll();
			for (Employee emplo : myEmp) {
				System.out.println(" Id is "+emplo.getEmpId());
				System.out.println(" Name is "+emplo.getEmpName());
				System.out.println(" Department is "+emplo.getEmpDepartment());
				System.out.println(" Salary is "+emplo.getEmpSalary());
			}
			break;
		case 3: //Search 
			System.out.println("Enter Employee Id");
			int id=scr.nextInt();
			
		Employee empSearch=empService.searchEmployee(id);
		
		System.out.println(" Id is "+empSearch.getEmpId());
		System.out.println(" Name is "+empSearch.getEmpName());
		System.out.println(" Department is "+empSearch.getEmpDepartment());
		System.out.println(" Salary is "+empSearch.getEmpSalary());
			
			break;
		case 4://Remove
			System.out.println("Enter Employee Id");
			int idRemove=scr.nextInt();
			empService.removeEmployee(idRemove);
			break;
		case 5://Exit
			
			break;
			
		}
			
			
		}while(choice!=5);
		

	}
	
	public static void printDetail(){
		System.out.println("**********");
		System.out.println("1. Add Employee ");
		System.out.println("2. Show All Employee");
		System.out.println("3. Search Employee");
		System.out.println("4. Remove Employee ");
		System.out.println("5. Exit");
		System.out.println("***********");
	}

}
