package com.cg.employeemanagment.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.cg.employeemanagment.exception.EmployeeException;



public class DbUtil {
private static final Logger mylogger=
Logger.getLogger(DbUtil.class);
	static Connection con=null;
	public static Connection getConnection() throws EmployeeException{
		
		Properties pros=new Properties();
		try {
	InputStream fileRead=new FileInputStream("oracle.properties");
	pros.load(fileRead);
	String driver=pros.getProperty("oracle.driver");
	String url=pros.getProperty("oracle.url");
	String userName=pros.getProperty("oracle.uname");
	String password=pros.getProperty("oracle.upass");
	
	Class.forName(driver);
con=DriverManager.getConnection(url, userName, password);
			
mylogger.info("Coneection Esablished.....");
			
		} catch (IOException | ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			mylogger.error("Coneection Not Esablished....."+e);
			throw new EmployeeException("Coneection Not Esablished.....");
			
		}
		return con;
	}
}
