package com.cg.employeemanagment.exception;

public class EmployeeException extends Exception{
	
	public EmployeeException() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	public EmployeeException(String msg){
		super(msg);
	}

}
