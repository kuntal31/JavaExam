package com.capGemini.banking.dto;

import java.util.Date;

public class AccountDto {

	private long Account_ID;
	private String 	Account_Type;
	private double Account_Balance;
	private	Date Open_Date;
	public long getAccount_ID() {
		return Account_ID;
	}
	public void setAccount_ID(long account_ID) {
		Account_ID = account_ID;
	}
	public String getAccount_Type() {
		return Account_Type;
	}
	public void setAccount_Type(String account_Type) {
		Account_Type = account_Type;
	}
	public double getAccount_Balance() {
		return Account_Balance;
	}
	public void setAccount_Balance(double account_Balance) {
		Account_Balance = account_Balance;
	}
	public Date getOpen_Date() {
		return Open_Date;
	}
	public void setOpen_Date(Date open_Date) {
		Open_Date = open_Date;
	}
	public AccountDto() {
		super();
	}
	public AccountDto(long account_ID, String account_Type,
			double account_Balance, Date open_Date) {
		super();
		Account_ID = account_ID;
		Account_Type = account_Type;
		Account_Balance = account_Balance;
		Open_Date = open_Date;
	}
	@Override
	public String toString() {
		return "AccountDto [Account_ID=" + Account_ID + ", Account_Type="
				+ Account_Type + ", Account_Balance=" + Account_Balance
				+ ", Open_Date=" + Open_Date + "]";
	}
	
	
	
}
