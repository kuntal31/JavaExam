package com.capGemini.banking.service;


import com.capGemini.banking.dto.AccountDto;
import com.capGemini.banking.dto.CustomerDto;
import com.capGemini.banking.dto.UserDto;
import com.capGemini.banking.exception.BankingException;

public interface BankingService {
	int addCustDetails(CustomerDto cust,AccountDto acc) throws BankingException;
	 UserDto getUserDto(long accId) throws BankingException;
}
