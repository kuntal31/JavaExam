package com.Lab11.ma.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.Lab11.ma.dto.Mobile;
import com.Lab11.ma.dto.Purchase;
import com.Lab11.ma.exception.MobileException;
import com.Lab11.ma.services.IMobileService;
import com.Lab11.ma.services.MobileServiceImpl;
import com.Lab11.ma.services.PurchaseServiceImpl;

public class MobileApplication {

	public static void main(String[] args) throws MobileException {
		
		IMobileService msi = new MobileServiceImpl();
		Purchase p= new Purchase();
		Scanner sc= new Scanner(System.in);
		int choice=0;
		do{
			printDetails();
			Scanner scr=new Scanner(System.in);
			choice=scr.nextInt();	
		
		switch(choice){
		case 1: //ADD
			//for customer name
			
			String patt="^[A-Z]{1}[a-z]{19}";
			System.out.println("Enter Customer name: ");
			String cname = sc.next();
			if(!PurchaseServiceImpl.validateName(patt,cname)){
				throw new MobileException("invalid");
			}
			else{
			p.setcName(cname);
			//for mail id
			String epatt="^[A-Za-z-9+_.-]+@(.+)$";
			System.out.println("Enter email id: ");
			String mailid=sc.next();
			
			if(!PurchaseServiceImpl.evalidateName(epatt, mailid)){
				throw new MobileException("invalid");
			}
			else{
				
			p.setMailId(mailid);
			//for phone no
			String ppatt="^[1-9]\\d(9)$";
			System.out.println("Enter Phone no: ");
			String phoneno=sc.next();
			if(!PurchaseServiceImpl.pvalidateName(ppatt, phoneno)){
				throw new MobileException("invalid");
			}
			else{
			//for mobile id 
			p.setPhoneNo(phoneno);
			String mpatt="^[0-9](4)\\d$";
			System.out.println("Enter Mobile id: ");
			String mobileId=sc.next();
			if(!PurchaseServiceImpl.mvalidateName(mpatt, mobileId)){
				throw new MobileException("invalid");
			}
			
			//for purchase date
			else{
				
			p.setMobileId(mobileId);
				String dpatt="^\\d{4}-\\d{2}-\\d{2}$";
			
			System.out.println("Enter purchase date: ");
			String pdate= sc.next();
			if(!PurchaseServiceImpl.dvalidateName(dpatt, pdate)){
				throw new MobileException("invalid");
			}
			else{
				p.setPurchaseDate(pdate);
			}
			
			}
			}
			}
			}
		case 2: List<Mobile>mList = new ArrayList<Mobile>();
		mList=msi.showAllMobiles();
		System.out.println(mList);
	break;
		case 3: 
			
		}
		
		}while(choice!=5);
	}
	
	

	public static void printDetails() {
		System.out.println("**********");
		System.out.println("1. Enter Purchase Details");
		System.out.println("2. Show All Mobile");
		System.out.println("3. Delete a mobile purchase");
		System.out.println("4. Search Mobile");
		System.out.println("5. Exit");
		System.out.println("***********");
	}

}
