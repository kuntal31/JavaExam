package com.Lab11.ma.services;

import java.util.List;

import com.Lab11.ma.dto.Mobile;
import com.Lab11.ma.exception.MobileException;

public interface IMobileService {

	public List<Mobile> showAllMobiles() throws MobileException;
	public boolean deleteMobile(int mobileId) throws MobileException;
	public List<Mobile> searchMobile(int start,int end) throws MobileException;
	
	
}
