package com.Lab11.ma.dao;

public interface IPurchaseDao {

	public void insertPurchaseDetails();
	
	
}
