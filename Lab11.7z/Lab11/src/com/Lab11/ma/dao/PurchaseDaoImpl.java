package com.Lab11.ma.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.Lab11.ma.dto.Mobile;
import com.Lab11.ma.dto.Purchase;
import com.Lab11.ma.util.JdbcUtil;

public class PurchaseDaoImpl implements IPurchaseDao{

	Connection con;
	PreparedStatement ps;
	ResultSet rs;
	Purchase p = new Purchase();
	public void insertPurchaseDetails() {
		
		
			con = JdbcUtil.getConnection();
			String query ="INSERT INTO PURCHASEDETAILS VALUES(?,?,?,?,?,?)";
			int status=0;
			try {
				ps=con.prepareStatement(query);
				ps.setInt(1, p.getMobileId());
				ps.setString(2,p.getcName());
				ps.setString(3, p.getMailId());
				ps.setInt(4, p.getPhoneNo());
				ps.setString(5, p.getPurchaseDate());
				ps.setInt(6, p.getMobileId());
				
				status =ps.executeUpdate();
				if(status!=0){
					System.out.println("Inserted successfully");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				try {
					ps.close();
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			
		}
		
	}


